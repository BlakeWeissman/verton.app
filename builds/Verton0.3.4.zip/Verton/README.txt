VERTON 0.3.4
Released 11/27/18

How to use:
-Install all fonts in the fonts folder.
-Launch "Verton.exe" to use Verton.

Changelog:
-Changed the margins of certain bodies of text

Known issues:
-The keywords list and actions list in the command creator have have some selection issues.
-When deleting an action from the actions list in command creator, if there is more than one of a specfic type of action on the actions list then deleting one of them will always delete the most recently created one instead on the selected one to delete.
-Closing or canceling the "open folder" file dialog in command creator results in an application crash