VERTON 0.3.3
Released 11/27/18

How to use:
-Install all fonts in the fonts folder.
-Launch "Verton.exe" to use Verton.

Changelog:
-Fixed issue where the application would crash if a user tried to import a command into the command creator
-Changed the margins of certain bodies of text to be more dynamic
-Fixed issue when a user would input a command through text they had to use a keyword and could not type anything else unlike voice input

Known issues:
-The keywords list and actions list in the command creator have have some selection issues.
-When deleting an action from the actions list in command creator, if there is more than one of a specfic type of action on the actions list then deleting one of them will always delete the most recently created one instead on the selected one to delete.
-Closing or canceling the "open folder" file dialog in command creator results in an application crash