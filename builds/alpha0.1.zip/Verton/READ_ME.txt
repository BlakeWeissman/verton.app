How To Install/Run Verton:

1. Install the font provided
2. Double Click "Verton.Bat"
3. Use Verton