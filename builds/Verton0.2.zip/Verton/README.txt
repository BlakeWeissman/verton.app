VERTON 0.2
Released 10/8/17

How to use:
-Launch "Verton.exe" to use Verton
-If text looks werid, install all fonts in the "fonts" folder

Changelog:
-Changed color scheme
-Changed font
-Added drop shadows to visual elements
-Improved the Verton button "hitbox"
-Revised settings page layout
-Revised listening page layout
-Added home page animations toggle in settings
-Added commands list in settings
-Added command editor button in settings(Does nothing right now)
-Changed application icon
-Application now stays pinned
-Changed how the application creates and locates libraries in order to clean the application folder

Known issues:
-Application crashes when changing the animations toggle. The setting still works though






