VERTON 0.3
Released 11/20/18

How to use:
-Install all fonts in the fonts folder.
-Launch "Verton.exe" to use Verton.

Changelog:
-Fixed bug where the app crashes when changing the home animations toggle
-Added a "restart required" message when changing the home animations toggle
-Added tool tips to the settings page
-Changed rendering method for drop shadows
-Removed drop shadows for text
-Added a home page drop shadow toggle in settings
-Removed "create command" button in settings page and replaced it with a "command creator" menu bar button
-Added the command creator, which allows a user to create, edit, duplicate, and remove commands
-Added a text input for commands as an alternative to saying commands
-Changed button layout for the "listening" page
-Overhauled the system used to recognize, store, and execute commands
-Users are now prevented from interacting with Verton if there are no commands
-Added a command text file editor that allows a user to edit "commands.txt" inside the application as a "low level" alternative to the command creator. The "commands.txt" file is where all commands are stored in, retrieved, and executed from. This editor can be accessed in the settings page
-Added a debug mode for commands to test for possible errors for custom commands, can be enabled and disabled in settings
-Added a built-in updater that allows Verton to easily update to future versions
-Added a "report issue" button in settings that takes the user to the contact form on the Verton website
-Changed the application icon
-Fixed issue where the settings page could be seen shortly when the application was launched

Known issues:
-The keywords list and actions list in the command creator have have some selection issues.
-When deleting an action from the actions list in command creator, if there is more than one of a specfic type of action on the actions list then deleting one of them will always delete the most recently created one instead on the selected one to delete.
-Closing or canceling the "open folder" file dialog in command creator results in an application crash
-If the user does not have a recording device then the application will crash when going to the listening page